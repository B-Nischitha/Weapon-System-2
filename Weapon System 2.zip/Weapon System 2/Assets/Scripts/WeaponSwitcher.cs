using UnityEngine;

public class WeaponSwitcher : MonoBehaviour
{
    public GameObject fireWeapon;
    public GameObject iceWeapon;
    public GameObject electricWeapon;

    public void SetFireWeapon()
    {
        fireWeapon.SetActive(true);
        iceWeapon.SetActive(false);
        electricWeapon.SetActive(false);
    }

    public void SetIceWeapon()
    {
        fireWeapon.SetActive(false);
        iceWeapon.SetActive(true);
        electricWeapon.SetActive(false);
    }

    public void SetElectricWeapon()
    {
        fireWeapon.SetActive(false);
        iceWeapon.SetActive(false);
        electricWeapon.SetActive(true);
    }
}