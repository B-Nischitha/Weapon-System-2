using UnityEngine;

public class WeaponController : MonoBehaviour
{
    public WeaponSwitcher weaponSwitcher;

    public void SelectFireWeapon()
    {
        if (weaponSwitcher != null)
        {
            weaponSwitcher.SetFireWeapon();
        }
    }

    public void SelectIceWeapon()
    {
        if (weaponSwitcher != null)
        {
            weaponSwitcher.SetIceWeapon();
        }
    }

    public void SelectElectricWeapon()
    {
        if (weaponSwitcher != null)
        {
            weaponSwitcher.SetElectricWeapon();
        }
    }
}
